import "../../temp/scripts/modernizr";
import 'picturefill';
import 'lazysizes';